HARD_LEVEL_TURNS= 5
EASY_LEVEL_TURNS= 10
from random import randint

def difficulty():
  level= input("choice a difficulty. type 'easy' or 'hard'.\n")
  if level == "easy":
    return EASY_LEVEL_TURNS
  elif level == "hard":
    return HARD_LEVEL_TURNS
  else:
    print("please input a valid input")


def guess_check(guess, number, turns):
  if guess == number:
    print("you got the number correct")
  elif guess > number:
    print ("to high")
    return turns -1
  else:
    print("to low")
    return turns -1

from art import logo
def game():
  
  print("welcome to the number guessing game")
  print("im thinking of number between 1 - 100.") 
  number= randint(1, 100)
  print( f"the number is {number}")
  turns= difficulty()
  guess = 0
  

  while guess != number:
    print (f"you have {turns} turns left") 
    guess= int(input("make a guess   "))
    turns= guess_check(guess, number, turns)
    if turns == 0:
      print("you have ran out of guesses")
      quit()
    elif guess != number:
      print( "make another guess")
    
      
game()









