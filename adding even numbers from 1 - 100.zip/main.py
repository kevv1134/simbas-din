#Write your code below this row 👇
total = 0 
for i in range(2,101,2):
    total += i  
print(total)


