# 🚨 Don't change the code below 👇
print("Welcome to the Love Calculator!")
name1 = input("What is your name? \n")
name2 = input("What is their name? \n")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇
names_combined= name1 + name2
names_lower= names_combined.lower()
t= names_lower.count("t")
r= names_lower.count("r")
u= names_lower.count("u")
e= names_lower.count("e")

l= names_lower.count("l")
o= names_lower.count("o")
v= names_lower.count("v")
e= names_lower.count("e")

score1= t + r + u + e
score2= l + o + v + e
score_love= int(str(score1) + str(score2))

if (score_love < 10) or (score_love> 90):
    print(f"your score is {score_love} yall are like cookies and cream")
elif score_love >=40 and  score_love <= 50:
    print(f"your score is {score_love} you are ok")
else:
    print(f"your score is {score_love}")