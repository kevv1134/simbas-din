# 🚨 Don't change the code below 👇
number = int(input("Which number do you want to check? "))
# 🚨 Don't change the code above 👆

#Write your code below this line 👇
pop= number%2
if pop<= 0:
    print("this number is even")
else:
    print("this number is odd")


