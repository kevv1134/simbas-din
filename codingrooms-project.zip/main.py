# 🚨 Don't change the code below 👇
height = float(input("enter your height in m: "))
weight = float(input("enter your weight in kg: "))
# 🚨 Don't change the code above 👆

#Write your code below this line 👇
BMi= round(weight / height **2)
if BMi < 18.5:
    print(f"your bmi is {BMi}, you are underweight") 
elif BMi < 25:
    print(f"your bmi is {BMi},you are mormal")
elif BMi <30:
    print(f"your bmi is {BMi}, your are slightyly over")
elif BMi < 35:
    print(f' Your bmi is {BMi}, You are obese')
elif BMi > 35:
    print(f' your bmi is {BMi}, your clinically obese')