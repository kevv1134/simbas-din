# 🚨 Don't change the code below 👇
student_heights = input("Input a list of student heights ").split()
for n in range(0, len(student_heights)):
  student_heights[n] = int(student_heights[n])
# 🚨 Don't change the code above 👆
num_heights=0
stud_heights=0

for student in student_heights:
    num_heights += 1

for height in student_heights:
    stud_heights += height

average= round(stud_heights / num_heights)
print(average)


#Write your code below this row 👇




