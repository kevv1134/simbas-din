# 🚨 Don't change the code below 👇
height = input("enter your height in m: ")
weight = input("enter your weight in kg: ")
# 🚨 Don't change the code above 👆
BMI=float(weight)/ float(height)**2
BMI_Int= int(BMI)
print(BMI_Int)
#Write your code below this line 👇
